package com.example.appqr

class User {
    val codigo:String = ""
     val nobmres:String =""
     val apellidos:String = ""



}