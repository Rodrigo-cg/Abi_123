package com.example.appqr.model

data class responseCert(
val datos: List<dataCert>,
)
