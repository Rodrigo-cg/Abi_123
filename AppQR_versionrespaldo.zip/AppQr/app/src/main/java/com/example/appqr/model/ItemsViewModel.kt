package com.example.appqr.model

data class ItemsViewModel(val text: String)
