package com.example.appqr

 data class Certificados (
    var razon:String? = null,
    var representante:String? = null,
     var direccion:String? = null,
    var actividad:String? = null,
     var fechaVencimiento:String? = null,
     var vigencia:String? = null,

 )