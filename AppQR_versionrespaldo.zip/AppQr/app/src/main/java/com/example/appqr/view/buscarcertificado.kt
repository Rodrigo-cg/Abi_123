package com.example.appqr

import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.ktx.Firebase
import java.text.SimpleDateFormat
import java.util.*

interface ciudadano {
    fun buscardcertificados()
    fun showcouponds()




}