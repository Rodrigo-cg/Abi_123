package com.example.appqr.model

data class dataList (
        /*var Estado  : String? = null,
        var Lic_func: String? = null,
        var Nombre_Razon: String? = null,
        var direccion: String? = null,
        var zona: String? = null,
        var Num_Res: String? = null,
        var  Num_Exp: String? = null,
        var  Giro: String? = null,
        var  Area: String? = null,
        var  Fecha_Exp: String? = null,
        var  Fecha_Caducidad: String? = null,*/
        var Tipo_parametro:String?= null,
        var parametro:String?=null
)


